import React from 'react';
import ProductListPageClient from './ProductListPageClient';
export default function ProductGrid(){
  return <ProductListPageClient />;
}
